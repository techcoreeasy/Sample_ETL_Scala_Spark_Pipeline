# Service-Text-Classification-Data-Processing-Pipeline

This project will do the pre-processing on the data before model building. So this output becomes the input for the model building pipeline.