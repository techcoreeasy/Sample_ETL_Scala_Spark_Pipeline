package com.myhammer.net.pipeline

/** A Pipeline composed of [[Stage]]. It is an abstraction of a computation composed of many processing.
  *
  * @param stages the processing of the computation
  * @param f      the computation
  * @tparam IN  the input type of the computation
  * @tparam OUT the output type of the computation
  */
class Pipeline[-IN, +OUT] private(val stages: Seq[Stage[_, _]])(f: IN => OUT) extends Stage[IN, OUT] {

  /** Alias of [[Pipeline#pipe[C](stage*]]
    */
  def ->[C](stage: Stage[OUT, C]): Pipeline[IN, C] = pipe(stage)

  /** Creates a new Pipeline by adding a stage at the end of this Pipeline
    *
    * @param stage the stage chained at the end
    * @tparam C the output type of stage
    * @return a new pipeline composed of this pipeline plus the stage
    */
  def pipe[C](stage: Stage[OUT, C]): Pipeline[IN, C] =
    new Pipeline(stages :+ stage)(f andThen stage.process)

  /** Alias of [[Pipeline#pipe[C](stage*]]
    */
  def ->[C](g: OUT => C): Pipeline[IN, C] = pipe(g)

  /** Creates a new Pipeline by adding a stage made of the function g at the end of this Pipeline
    *
    * @param g the function chained at the end
    * @tparam C the output type of stage
    * @return a new pipeline composed of this pipeline plus the stage
    */
  def pipe[C](g: OUT => C): Pipeline[IN, C] =
    new Pipeline(stages :+ Stage(f))(f andThen g)

  /** Alias of [[Pipeline#pipe[C](stage*]]
    */
  def ->[C](other: Pipeline[OUT, C]): Pipeline[IN, C] = pipe(other)

  /** Creates a new Pipeline by chaining all the processing of this Pipeline and the other Pipeline
    *
    * @param other the other pipeline
    * @tparam C the output type of the pipeline
    * @return a new pipeline with the union of the processing
    */
  def pipe[C](other: Pipeline[OUT, C]): Pipeline[IN, C] =
    new Pipeline(stages ++ other.stages)(f andThen other.process)

  /** Executes the computation with a given input
    *
    * @param in the input of the computation
    * @return the result of the computation
    */
  override def process(in: IN): OUT = f(in)

  /** Alias of [[Pipeline#pipe[C](stage*]]
    */
  def :+[C](stage: Stage[OUT, C]): Pipeline[IN, C] = pipe(stage)

  /** Alias of [[Pipeline#pipe[C](stage*]]
    */
  def :+[C](g: OUT => C): Pipeline[IN, C] = pipe(g)

  /** Alias of [[Pipeline#pipe[C](stage*]]
    */
  def :+[C](other: Pipeline[OUT, C]): Pipeline[IN, C] = pipe(other)

  override def equals(that: Any): Boolean =
    that match {
      case that: Pipeline[IN, OUT] => that.canEqual(this) && stages.equals(that.stages)
      case _ => false
    }

  def canEqual(a: Any): Boolean = a.isInstanceOf[Pipeline[IN, OUT]]

  override def hashCode(): Int =
    this.stages.hashCode()

  override def toString: String = stages.mkString("Pipeline(", " -> ", ")")
}

/** Factory for [[Pipeline]].
  */
object Pipeline {

  def compose[A](pipelines: Traversable[Pipeline[A, A]]): Pipeline[A, A] = pipelines.foldLeft(Pipeline[A]())((accumulator, p) => accumulator.pipe[A](p))

  /** Creates an Empty Pipeline
    *
    * @return the empty pipeline
    */
  def apply[A](): Pipeline[A, A] =
    new Pipeline[A, A](List.empty)(identity)

  /** Creates a Pipeline from a stage
    *
    * @param s the stage
    * @tparam A the input type of the stage
    * @tparam B the output type of the stage
    * @return the pipeline composed by the stage
    */
  def apply[A, B](s: Stage[A, B]): Pipeline[A, B] =
    new Pipeline[A, B](List(s))(s.process)

  /** Creates a Pipeline from a function
    *
    * @param f the function
    * @tparam A the input type of the function
    * @tparam B the output type of the function
    * @return the pipeline composed by the function
    */
  def apply[A, B](f: A => B): Pipeline[A, B] =
    new Pipeline[A, B](List(Stage(f)))(f)

  /** Implicit conversion from Pipeline to Function1
    *
    * @param p
    * @tparam IN
    * @tparam OUT
    * @return
    */
  implicit def pipelineToFunction[IN, OUT](p: Pipeline[IN, OUT]): IN => OUT = p.process
}
